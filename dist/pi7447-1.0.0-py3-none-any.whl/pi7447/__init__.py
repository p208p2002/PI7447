from pi7447.pi7447 import IC7447
name = "pi7447"